"""Service-owned application contracts."""
