# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: fleet.spec.ts >> discovers, groups and prepares source VMs with independent holds and current-group checks
- Location: tests/browser-p08/fleet.spec.ts:4:1

# Error details

```
Test timeout of 60000ms exceeded.
```

```
Error: locator.selectOption: Test timeout of 60000ms exceeded.
Call log:
  - waiting for getByLabel('Source connection', { exact: true })

```

# Page snapshot

```yaml
- main [ref=e3]:
  - navigation "Workspace navigation" [ref=e4]:
    - link "Your tenants" [ref=e5] [cursor=pointer]:
      - /url: /account
    - link "Tenant settings" [ref=e6] [cursor=pointer]:
      - /url: /tenants/aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa
    - link "Applications" [ref=e7] [cursor=pointer]:
      - /url: /tenants/aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa/applications
    - link "Environments and domains" [ref=e8] [cursor=pointer]:
      - /url: /tenants/aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa/catalogue-references
    - link "Observed inventory" [ref=e9] [cursor=pointer]:
      - /url: /tenants/aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa/inventory
    - button "Sign out" [ref=e10] [cursor=pointer]
  - heading "Migrate to OpenStack" [active] [level=1] [ref=e11]
  - generic [ref=e12]:
    - link "Site inventory" [ref=e13] [cursor=pointer]:
      - /url: /tenants/aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa/inventory/sites/bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb
    - link "Source and target connections" [ref=e14] [cursor=pointer]:
      - /url: /tenants/aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa/inventory/sites/bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb/configuration
  - paragraph [ref=e15]: Discover source VMs through the enrolled platform APIs, organize them into migration groups, and prepare selected machines for OpenStack. Each VM keeps its own disk mapping, method and readiness review.
  - region "API source collection" [ref=e16]:
    - generic [ref=e17]:
      - text: Source connection
      - combobox "Source connection" [ref=e18]:
        - option "Choose an enrolled source" [selected]
        - option "vCenter Ottawa · datacenter-1"
    - button "Refresh from API" [disabled] [ref=e19]
    - button "Refresh findings" [ref=e20] [cursor=pointer]
    - paragraph [ref=e21]: Collection uses existing read permissions and scope. Only complete generations appear below. Additional connections are available through Site inventory.
  - generic "Selected resources" [ref=e22]:
    - generic [ref=e23]:
      - generic [ref=e24]: Selected VMs
      - strong [ref=e25]: "0"
      - text: of 50 per group
    - generic [ref=e26]:
      - generic [ref=e27]: Observed vCPUs
      - strong [ref=e28]: "0"
    - generic [ref=e29]:
      - generic [ref=e30]: Observed memory
      - strong [ref=e31]: 0.0 GiB
    - generic [ref=e32]:
      - generic [ref=e33]: Profiled disks
      - strong [ref=e34]: 0.0 GiB
      - paragraph [ref=e35]: Unknown values excluded; capacity is not reserved.
  - region "Discovered source machines" [ref=e36]:
    - generic [ref=e37]:
      - generic [ref=e38]:
        - text: Find VMs
        - textbox "Find VMs" [ref=e39]:
          - /placeholder: Name, source ID, connection, guest OS or power state
      - generic [ref=e40]:
        - text: Readiness
        - combobox "Readiness" [ref=e41]:
          - option "All discovered VMs" [selected]
          - option "Ready for owner review"
          - option "Held"
      - generic [ref=e42]:
        - text: Group list by
        - combobox "Group list by" [ref=e43]:
          - option "Source connection" [selected]
          - option "Guest OS"
          - option "Power state"
          - option "Readiness"
    - generic [ref=e44]:
      - button "Select filtered VMs" [ref=e45] [cursor=pointer]
      - button "Clear selection" [disabled] [ref=e46]
      - generic [ref=e47]: 3 matching of 3 loaded. Selections remain when filters change.
    - generic [ref=e48]:
      - generic [ref=e49]:
        - heading "vCenter Ottawa · 3 VMs" [level=2] [ref=e50]
        - button "Select group vCenter Ottawa" [ref=e51] [cursor=pointer]: Select group
      - table [ref=e53]:
        - caption [ref=e54]: Discovered VMs in vCenter Ottawa
        - rowgroup [ref=e55]:
          - row [ref=e56]:
            - columnheader "Select" [ref=e57]
            - columnheader "Source VM" [ref=e58]
            - columnheader "Power / guest" [ref=e59]
            - columnheader "Resources" [ref=e60]
            - columnheader "Migration readiness" [ref=e61]
            - columnheader "Review" [ref=e62]
        - rowgroup [ref=e63]:
          - row [ref=e64]:
            - cell [ref=e65]:
              - checkbox "Select accounts-api (vm-1)" [ref=e66]
            - cell [ref=e67]:
              - strong [ref=e68]: accounts-api
              - paragraph [ref=e69]: vm-1 · datacenter-1
              - paragraph [ref=e70]: Observed 10/7/2026, 2:44:46 PM
            - cell [ref=e71]:
              - text: poweredOff
              - paragraph [ref=e72]: ubuntu64Guest
            - cell [ref=e73]:
              - text: 2 vCPU · 4.0 GiB
              - paragraph [ref=e74]: 2 disks
            - cell "Owner review required" [ref=e75]:
              - text: Owner review required
              - list
            - cell [ref=e76]:
              - link "Review VM" [ref=e77] [cursor=pointer]:
                - /url: /tenants/aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa/inventory/sites/bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb/migration/profiles/febaa3f9-48e1-44c6-8491-066f1a2c5376
          - row [ref=e78]:
            - cell [ref=e79]:
              - checkbox "Select accounts-db (vm-2)" [ref=e80]
            - cell [ref=e81]:
              - strong [ref=e82]: accounts-db
              - paragraph [ref=e83]: vm-2 · datacenter-1
              - paragraph [ref=e84]: Observed 10/7/2026, 2:44:46 PM
            - cell [ref=e85]:
              - text: poweredOn
              - paragraph [ref=e86]: ubuntu64Guest
            - cell [ref=e87]:
              - text: 8 vCPU · 16.0 GiB
              - paragraph [ref=e88]: 2 disks
            - cell "Owner review required" [ref=e89]:
              - text: Owner review required
              - list
            - cell [ref=e90]:
              - link "Review VM" [ref=e91] [cursor=pointer]:
                - /url: /tenants/aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa/inventory/sites/bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb/migration/profiles/b727b341-b84d-4ec0-afd4-6ef81978a958
          - row [ref=e92]:
            - cell [ref=e93]:
              - checkbox "Select legacy <img src=x onerror=alert(1)> (vm-3)" [ref=e94]
            - cell [ref=e95]:
              - strong [ref=e96]: legacy <img src=x onerror=alert(1)>
              - paragraph [ref=e97]: vm-3 · datacenter-1
              - paragraph [ref=e98]: Observed 10/7/2026, 2:44:46 PM
            - cell [ref=e99]:
              - text: poweredOn
              - paragraph [ref=e100]: Guest profile required
            - cell [ref=e101]:
              - text: 2 vCPU · 4.0 GiB
              - paragraph [ref=e102]: "? disks"
            - cell [ref=e103]:
              - text: Held
              - list [ref=e104]:
                - listitem [ref=e105]: source profile required
            - cell "Collect detailed profile" [ref=e106]
    - button "Load more source VMs" [ref=e107] [cursor=pointer]
    - paragraph [ref=e108]: Detailed profiles must be included in the enrolled source scope. Discovery and selection alone do not establish migration compatibility.
  - generic [ref=e109]:
    - heading "Save a migration group" [level=2] [ref=e110]
    - paragraph [ref=e111]: Use a group for an application, environment or migration wave. Application and environment IDs refer to your catalogue; platform APIs cannot determine ownership.
    - group "Migration group details" [ref=e113]:
      - generic [ref=e115]:
        - text: Group name
        - textbox "Group name" [ref=e116]:
          - /placeholder: Finance · production · wave 1
      - generic [ref=e117]:
        - text: OpenStack destination
        - combobox "OpenStack destination" [ref=e118]:
          - option "Select a current target project" [selected]
          - option "OpenStack · project-finance"
      - generic [ref=e119]:
        - text: Catalogue application ID
        - textbox "Catalogue application ID" [ref=e120]
      - generic [ref=e121]:
        - text: Catalogue environment ID
        - textbox "Catalogue environment ID" [ref=e122]
      - generic [ref=e123]:
        - text: Target disk format
        - combobox "Target disk format" [ref=e124]:
          - option "RAW" [disabled]
          - option "QCOW2" [disabled] [selected]
      - button "Save migration group" [disabled] [ref=e126]
  - generic [ref=e127]:
    - heading "Saved migration groups" [level=2] [ref=e128]
    - paragraph [ref=e129]: No groups saved yet.
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | const base = '/tenants/aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa/inventory/sites/bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb/migration-fleet';
  3  | 
  4  | test('discovers, groups and prepares source VMs with independent holds and current-group checks', async ({ page, request }, info) => {
  5  |   await request.post('/__fleet', { data: { reset: true } });
  6  |   const initial = await (await request.get('/__fleet')).json();
  7  |   const errors: string[] = []; page.on('pageerror', e => errors.push(e.message));
  8  |   await page.goto(base);
  9  |   await expect(page.getByRole('heading', { name: 'Migrate to OpenStack', exact: true })).toBeFocused();
> 10 |   await page.getByLabel('Source connection', { exact: true }).selectOption(initial.endpoints.items[0].endpoint_id);
     |                                                               ^ Error: locator.selectOption: Test timeout of 60000ms exceeded.
  11 |   await page.getByRole('button', { name: 'Refresh from API', exact: true }).click();
  12 |   await expect(page.getByRole('status')).toContainText('API discovery queued.');
  13 |   await expect(page.locator('img')).toHaveCount(0);
  14 |   await page.getByLabel('Find VMs').fill('accounts');
  15 |   await page.getByRole('button', { name: 'Select filtered VMs', exact: true }).click();
  16 |   await expect(page.getByRole('checkbox', { checked: true })).toHaveCount(2);
  17 |   await page.getByLabel('Find VMs').fill('');
  18 |   await page.getByLabel('Group list by').selectOption('guest_id');
  19 |   await expect(page.getByRole('heading', { name: 'ubuntu64Guest · 2 VMs', exact: true })).toBeVisible();
  20 |   await page.getByRole('button', { name: 'Load more source VMs', exact: true }).click();
  21 |   await expect(page.getByText('batch-worker', { exact: true })).toBeVisible();
  22 |   await expect(page.getByRole('checkbox', { checked: true })).toHaveCount(2);
  23 |   await page.getByLabel('Group name', { exact: true }).fill('Accounts · wave 1');
  24 |   await page.getByLabel('OpenStack destination').selectOption(initial.workspace.targets[0].id);
  25 |   await page.getByLabel('Catalogue application ID').fill(initial.endpoints.items[0].endpoint_id);
  26 |   await page.getByLabel('Catalogue environment ID').fill(initial.endpoints.items[0].endpoint_id);
  27 |   await page.getByRole('button', { name: 'Save migration group', exact: true }).click();
  28 |   await expect(page).toHaveURL(/\/groups\//);
  29 |   await page.getByRole('button', { name: 'Prepare group for OpenStack', exact: true }).click();
  30 |   await expect(page.getByText('1 prepared · 1 held', { exact: true })).toBeVisible();
  31 |   let state = await (await request.get('/__fleet')).json();
  32 |   expect(state.preparations).toHaveLength(2);
  33 |   expect(state.preparations[0].revision).toBe(state.group.revision);
  34 |   expect(Object.keys(state.preparations[0]).sort()).toEqual(['digest', 'resource_id', 'revision']);
  35 |   await page.screenshot({ path: info.outputPath('migration-fleet.png'), fullPage: true });
  36 |   await page.getByLabel('Group name', { exact: true }).fill('changed');
  37 |   await expect(page.getByRole('button', { name: 'Prepare group for OpenStack', exact: true })).toBeDisabled();
  38 |   await page.reload();
  39 |   await request.post('/__fleet', { data: { stale: true } });
  40 |   await page.getByRole('button', { name: 'Prepare group for OpenStack', exact: true }).click();
  41 |   await expect(page.getByText('Batch paused. Refresh current findings before preparing again.', { exact: true })).toBeVisible();
  42 |   state = await (await request.get('/__fleet')).json(); expect(state.preparations).toHaveLength(3);
  43 |   await request.post('/__fleet', { data: { access: 403 } });
  44 |   await expect(page).toHaveURL(/\/account$/, { timeout: 25_000 });
  45 |   expect(errors).toEqual([]);
  46 | });
  47 | 
```