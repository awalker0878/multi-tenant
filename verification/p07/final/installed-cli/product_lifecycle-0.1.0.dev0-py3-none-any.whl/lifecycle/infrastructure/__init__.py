"""Service-owned external adapters."""
