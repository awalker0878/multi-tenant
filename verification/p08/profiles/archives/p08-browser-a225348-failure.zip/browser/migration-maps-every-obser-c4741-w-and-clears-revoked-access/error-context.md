# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: migration.spec.ts >> maps every observed disk, preserves uncertain commands, confirms exact review, and clears revoked access
- Location: tests/browser-p08/migration.spec.ts:4:1

# Error details

```
Error: expect(locator).toBeFocused() failed

Locator: getByRole('heading', { name: 'Migration readiness review', exact: true })
Expected: focused
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeFocused" getByRole('heading', { name: 'Migration readiness review', exact: true }) with timeout 5000ms
  - waiting for getByRole('heading', { name: 'Migration readiness review', exact: true })

```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | const base = '/tenants/aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa/inventory/sites/bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb/migration';
  3  | 
  4  | test('maps every observed disk, preserves uncertain commands, confirms exact review, and clears revoked access', async ({ page, request }, info) => {
  5  |   await request.post('/__fixture', { data: { reset: true } });
  6  |   const state = await (await request.get('/__fixture')).json();
  7  |   const errors: string[] = [];
  8  |   page.on('pageerror', error => errors.push(error.message));
  9  |   await page.goto(base);
> 10 |   await expect(page.getByRole('heading', { name: 'Migration readiness review', exact: true })).toBeFocused();
     |                                                                                                ^ Error: expect(locator).toBeFocused() failed
  11 |   await expect(page.getByLabel('Explicit migration method')).toHaveValue('');
  12 |   await expect(page.getByRole('button', { name: 'Confirm migration review', exact: true })).toBeDisabled();
  13 |   await page.getByLabel('Source VM profile').selectOption(state.workspace.profiles[0].id);
  14 |   await page.getByLabel('OpenStack target profile').selectOption(state.workspace.profiles[1].id);
  15 |   await page.getByLabel('Explicit migration method').selectOption('VM_COLD_EXPORT');
  16 |   await expect(page.getByRole('button', { name: 'Save migration review', exact: true })).toBeDisabled();
  17 |   await page.getByRole('button', { name: 'Add dataset', exact: true }).click();
  18 |   await page.getByLabel('Name', { exact: true }).fill('Application and attachments');
  19 |   await page.getByLabel('Consistency group', { exact: true }).fill('all-data');
  20 |   await page.getByLabel('Mounts or dataset paths (one per line)').fill('/\n/data');
  21 |   await page.getByLabel('Correctness check reference').fill('synthetic-check-only');
  22 |   for (const disk of state.workspace.profiles[0].facts.disks) await page.getByLabel(`Disk ${disk.key}`, { exact: true }).check();
  23 |   await expect(page.getByText('Mapping required', { exact: true })).toHaveCount(0);
  24 |   for (const field of state.workspace.owner_fields) await page.getByLabel(field.replaceAll('_', ' '), { exact: true }).fill('synthetic-owner-reference');
  25 |   await page.getByLabel('Application owner ID').fill('cccccccc-cccc-4ccc-8ccc-cccccccccccc');
  26 |   await page.getByLabel('Acceptance record SHA-256').fill('c'.repeat(64));
  27 |   await page.getByLabel('Maximum outage (seconds)').fill('300');
  28 |   await page.getByLabel('Maximum data loss (bytes)').fill('0');
  29 |   await page.getByRole('button', { name: 'Add reasoned interpretation' }).click();
  30 |   await page.getByLabel('Interpretation', { exact: true }).fill('Quiesce application before capture');
  31 |   await page.getByLabel('Reason and evidence', { exact: true }).fill('Application owner decision R1');
  32 |   await request.post('/__fixture', { data: { uncertain: true } });
  33 |   await page.getByRole('button', { name: 'Save migration review', exact: true }).click();
  34 |   await expect(page.getByRole('alert')).toBeFocused();
  35 |   await expect(page.getByRole('alert')).toContainText('uncertain');
  36 |   await expect(page.getByLabel('Name', { exact: true })).toBeDisabled();
  37 |   await page.getByRole('button', { name: 'Retry unchanged command', exact: true }).click();
  38 |   await expect(page.getByRole('status')).toContainText('Migration review saved.');
  39 |   const posted = (await (await request.get('/__fixture')).json()).posts;
  40 |   expect(posted).toHaveLength(2); expect(posted[0]).toEqual(posted[1]);
  41 |   await expect(page.getByRole('button', { name: 'Confirm migration review', exact: true })).toBeEnabled();
  42 |   await page.getByLabel('Name', { exact: true }).fill('Changed after saving');
  43 |   await expect(page.getByRole('button', { name: 'Confirm migration review', exact: true })).toBeDisabled();
  44 |   await page.reload();
  45 |   await page.getByRole('button', { name: 'Confirm migration review', exact: true }).click();
  46 |   await expect(page.getByRole('status')).toContainText('Migration review confirmed.');
  47 |   await expect(page.getByRole('button', { name: 'Confirm migration review', exact: true })).toBeDisabled();
  48 |   await expect(page.locator('img')).toHaveCount(0);
  49 |   await page.screenshot({ path: info.outputPath('migration-review.png'), fullPage: true });
  50 |   await page.setViewportSize({ width: 640, height: 800 });
  51 |   await page.evaluate(() => { document.documentElement.style.zoom = '2'; });
  52 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 2)).toBe(true);
  53 |   await request.post('/__fixture', { data: { expire: true } });
  54 |   await page.reload();
  55 |   await expect(page.getByText('Revision 1 · Review required', { exact: true })).toBeVisible();
  56 |   await expect(page.getByRole('button', { name: 'Confirm migration review', exact: true })).toBeDisabled();
  57 |   await request.post('/__fixture', { data: { access: 403 } });
  58 |   await expect(page).toHaveURL(/\/account$/, { timeout: 25_000 });
  59 |   expect(errors).toEqual([]);
  60 | });
  61 | 
```