# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: operator-inputs.spec.ts >> collects operator inputs, preserves zero and uncertain saves, and remains usable on mobile
- Location: tests/browser-p08/operator-inputs.spec.ts:3:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('Evidence verified', { exact: true })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByText('Evidence verified', { exact: true }) with timeout 5000ms
  - waiting for getByText('Evidence verified', { exact: true })

```

```yaml
- link "Skip to workspace":
  - /url: "#workspace-main"
- complementary:
  - link "Workload Mobility home":
    - /url: /account
    - strong: Workload Mobility
    - text: Enterprise hosting
  - navigation "Workspace navigation":
    - paragraph: WORKSPACE
    - link "Your tenants":
      - /url: /account
    - link "Applications":
      - /url: /tenants/aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa/applications
    - link "Environments and domains":
      - /url: /tenants/aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa/catalogue-references
    - link "Observed inventory":
      - /url: /tenants/aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa/inventory
    - link "Tenant settings":
      - /url: /tenants/aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa
  - paragraph: Tenant workspace
  - code: aaaaaaaa
  - button "Sign out"
- banner: OPERATIONS CONSOLE Tenant scoped
- main:
  - paragraph: Workload Mobility / Workspace
  - heading "Operator readiness" [level=1]
  - paragraph: Prepare the access, recovery and operating information needed to commission this site. API-discovered configuration stays linked to its environment review.
  - link "Site inventory":
    - /url: /tenants/aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa/inventory/sites/bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb
  - link "Environment configuration":
    - /url: /tenants/aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa/inventory/sites/bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb/configuration
  - link "Workload migration review":
    - /url: /tenants/aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa/inventory/sites/bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb/migration
  - text: Operator action required
  - status: Operator inputs saved. Remaining requirements are listed below.
  - region "What are you preparing?":
    - heading "What are you preparing?" [level=2]
    - text: Task
    - combobox "Task":
      - option "Discover an environment"
      - option "Provision an application"
      - option "Migrate a workload" [selected]
      - option "Adopt existing resources"
      - option "Accept a service into operation"
      - option "Retire managed resources"
    - text: Migration method
    - combobox "Migration method":
      - option "application rebuild restore"
      - option "vm snapshot baseline app delta"
      - option "vm snapshot baseline file delta"
      - option "vm cold export" [selected]
      - option "external block replication"
    - paragraph: Requirements follow this task, its method and the API-observed environments. Changing this selection does not change or approve a workload migration plan.
    - paragraph: "Source: vmware · Destination: openstack"
  - text: INPUTS SUPPLIED
  - strong: 4 / 27
  - paragraph: Owner references and operating targets
  - text: ENVIRONMENT REVIEW
  - strong: Review needed
  - paragraph: Select and discover your environments
  - text: SAVED INPUT PACKET
  - strong: Revision 1
  - paragraph: 10/8/2026, 4:47:40 AM
  - complementary:
    - paragraph: REQUIRED INPUTS
    - heading "Commissioning checklist" [level=2]
    - paragraph: Only requirements for the selected task count. Partial drafts and values for other tasks are retained.
    - navigation "Operator input sections":
      - button "01 Accounts and trust 2 of 8 supplied" [pressed]:
        - text: "01"
        - strong: Accounts and trust
        - text: 2 of 8 supplied
      - button "02 Execution and independent verification 0 of 6 supplied":
        - text: "02"
        - strong: Execution and independent verification
        - text: 0 of 6 supplied
      - button "03 Application recovery and cutover 0 of 6 supplied":
        - text: "03"
        - strong: Application recovery and cutover
        - text: 0 of 6 supplied
      - button "04 Operating targets 2 of 5 supplied":
        - text: "04"
        - strong: Operating targets
        - text: 2 of 5 supplied
      - button "05 Qualification and service handover 0 of 2 supplied":
        - text: "05"
        - strong: Qualification and service handover
        - text: 0 of 2 supplied
    - paragraph: Native qualification remains separate
    - paragraph: Supplying a reference records an input. Its owner must verify the underlying evidence and approve the exact operating scope.
  - paragraph: Platform and identity owners
  - heading "Accounts and trust" [level=2]
  - text: 2 / 8 supplied
  - paragraph:
    - text: Enter protected record identifiers, such as
    - code: vault:site-a/source-execution
    - text: or
    - code: evidence:review-2026-04
    - text: . Keep passwords, access tokens and private keys in the approved secret store.
  - checkbox "Show inputs for other tasks"
  - text: Show inputs for other tasks
  - group "Accounts and trust inputs":
    - text: Accounts and trust inputs Source platform execution account reference Awaiting verification
    - textbox "Source platform execution account reference":
      - /placeholder: record:site-a/source_writer
      - text: vault:site/source-execution
    - paragraph: Protected secret-store record for the scoped execution identity. Supply its record identifier, never its secret value.
    - paragraph:
      - text: "Protected record identifier, 1–240 characters; no secret value or URL query. Example:"
      - code: record:site-a/source_writer
    - paragraph: "Responsible: Platform and identity owners"
    - text: Source platform verification account reference Awaiting verification
    - textbox "Source platform verification account reference":
      - /placeholder: record:site-a/source_observer
      - text: vault:site/source-verification
    - paragraph: Separate read-only identity used to verify effects independently of the execution account.
    - paragraph:
      - text: "Protected record identifier, 1–240 characters; no secret value or URL query. Example:"
      - code: record:site-a/source_observer
    - paragraph: "Responsible: Platform and identity owners"
    - text: Destination platform execution account reference Required
    - textbox "Destination platform execution account reference":
      - /placeholder: record:site-a/target_writer
    - paragraph: Protected secret-store record for the scoped execution identity. Supply its record identifier, never its secret value.
    - paragraph:
      - text: "Protected record identifier, 1–240 characters; no secret value or URL query. Example:"
      - code: record:site-a/target_writer
    - paragraph: "Responsible: Platform and identity owners"
    - text: Destination platform verification account reference Required
    - textbox "Destination platform verification account reference":
      - /placeholder: record:site-a/target_observer
    - paragraph: Separate read-only identity used to verify effects independently of the execution account.
    - paragraph:
      - text: "Protected record identifier, 1–240 characters; no secret value or URL query. Example:"
      - code: record:site-a/target_observer
    - paragraph: "Responsible: Platform and identity owners"
    - text: Image transfer execution account reference Required
    - textbox "Image transfer execution account reference":
      - /placeholder: record:site-a/image_writer
    - paragraph: Protected secret-store record for the scoped execution identity. Supply its record identifier, never its secret value.
    - paragraph:
      - text: "Protected record identifier, 1–240 characters; no secret value or URL query. Example:"
      - code: record:site-a/image_writer
    - paragraph: "Responsible: Platform and identity owners"
    - text: Image transfer verification account reference Required
    - textbox "Image transfer verification account reference":
      - /placeholder: record:site-a/image_observer
    - paragraph: Separate read-only identity used to verify effects independently of the execution account.
    - paragraph:
      - text: "Protected record identifier, 1–240 characters; no secret value or URL query. Example:"
      - code: record:site-a/image_observer
    - paragraph: "Responsible: Platform and identity owners"
    - text: Account permissions and scope record Required
    - textbox "Account permissions and scope record":
      - /placeholder: record:site-a/account_scope
    - paragraph: Approved projects, datacentres, resource scope, expiry and permissions for all six accounts.
    - paragraph:
      - text: "Protected record identifier, 1–240 characters; no secret value or URL query. Example:"
      - code: record:site-a/account_scope
    - paragraph: "Responsible: Platform and identity owners"
    - text: TLS trust and rotation record Required
    - textbox "TLS trust and rotation record":
      - /placeholder: record:site-a/trust_bundle
    - paragraph: Approved certificate authorities, endpoint identity checks, secret rotation and revocation procedure.
    - paragraph:
      - text: "Protected record identifier, 1–240 characters; no secret value or URL query. Example:"
      - code: record:site-a/trust_bundle
    - paragraph: "Responsible: Platform and identity owners"
  - button "Save operator inputs"
  - paragraph: Each save creates an attributable revision.
  - link "Download saved packet":
    - /url: /tenants/aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa/inventory/sites/bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb/operator-inputs/download
  - region "Remaining requirements":
    - button "Recheck evidence"
    - heading "Remaining requirements" [level=2]
    - list:
      - listitem: Required operator inputs are still missing. Each section shows what remains.
      - listitem: Collect and confirm the source and destination API findings in Environment configuration.
    - paragraph: Native testing, evidence validation and independent receiving decisions are still required before commissioning. Signed owner observations are checked against the saved packet and original evidence bytes. Native qualification and execution authority remain separate.
    - paragraph: Source platform execution account reference · Awaiting verification
    - paragraph: "Supply the approved value, then save this task's inputs. Responsible: Platform and identity owners"
    - paragraph: Source platform verification account reference · Awaiting verification
    - paragraph: "Supply the approved value, then save this task's inputs. Responsible: Platform and identity owners"
    - paragraph: Destination platform execution account reference · Required
    - paragraph: "Supply the approved value, then save this task's inputs. Responsible: Platform and identity owners"
    - paragraph: Destination platform verification account reference · Required
    - paragraph: "Supply the approved value, then save this task's inputs. Responsible: Platform and identity owners"
    - paragraph: Image transfer execution account reference · Required
    - paragraph: "Supply the approved value, then save this task's inputs. Responsible: Platform and identity owners"
    - paragraph: Image transfer verification account reference · Required
    - paragraph: "Supply the approved value, then save this task's inputs. Responsible: Platform and identity owners"
    - paragraph: Account permissions and scope record · Required
    - paragraph: "Supply the approved value, then save this task's inputs. Responsible: Platform and identity owners"
    - paragraph: TLS trust and rotation record · Required
    - paragraph: "Supply the approved value, then save this task's inputs. Responsible: Platform and identity owners"
    - paragraph: Independent recovery custody record · Required
    - paragraph: "Supply the approved value, then save this task's inputs. Responsible: Platform and security owners"
    - paragraph: Stale worker exclusion procedure · Required
    - paragraph: "Supply the approved value, then save this task's inputs. Responsible: Platform and security owners"
    - paragraph: Capacity and address reservation procedure · Required
    - paragraph: "Supply the approved value, then save this task's inputs. Responsible: Platform and security owners"
    - paragraph: Guest preparation recipe · Required
    - paragraph: "Supply the approved value, then save this task's inputs. Responsible: Platform and security owners"
    - paragraph: Shared service integration procedures · Required
    - paragraph: "Supply the approved value, then save this task's inputs. Responsible: Platform and security owners"
    - paragraph: Transfer and concurrency measurement record · Required
    - paragraph: "Supply the approved value, then save this task's inputs. Responsible: Platform and security owners"
    - paragraph: Application consistency procedure · Required
    - paragraph: "Supply the approved value, then save this task's inputs. Responsible: Application and service owners"
    - paragraph: Application writer isolation procedure · Required
    - paragraph: "Supply the approved value, then save this task's inputs. Responsible: Application and service owners"
    - paragraph: Traffic switch and policy validation procedure · Required
    - paragraph: "Supply the approved value, then save this task's inputs. Responsible: Application and service owners"
    - paragraph: Backup and restore validation record · Required
    - paragraph: "Supply the approved value, then save this task's inputs. Responsible: Application and service owners"
    - paragraph: Recovery before and after destination writes · Required
    - paragraph: "Supply the approved value, then save this task's inputs. Responsible: Application and service owners"
    - paragraph: Retirement and retention authorization · Required
    - paragraph: "Supply the approved value, then save this task's inputs. Responsible: Application and service owners"
    - paragraph: Approved operating objectives record · Required
    - paragraph: "Supply the approved value, then save this task's inputs. Responsible: Application and operations owners"
    - paragraph: Authorized qualification campaign · Required
    - paragraph: "Supply the approved value, then save this task's inputs. Responsible: Qualification and receiving teams"
    - paragraph: Installed release and artifact record · Required
    - paragraph: "Supply the approved value, then save this task's inputs. Responsible: Qualification and receiving teams"
    - paragraph: Maximum application outage (seconds) · Review expired
    - paragraph: "Review expired evidence and ask the owner to publish a current observation. Responsible: Application and operations owners"
    - paragraph: Maximum data loss (bytes) · Awaiting verification
    - paragraph: "Supply the approved value, then save this task's inputs. Responsible: Application and operations owners"
    - paragraph: Recovery time objective (seconds) · Required
    - paragraph: "Supply the approved value, then save this task's inputs. Responsible: Application and operations owners"
    - paragraph: Maximum simultaneous migrations · Required
    - paragraph: "Supply the approved value, then save this task's inputs. Responsible: Application and operations owners"
    - paragraph: "Packet SHA-256: aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
- contentinfo: Workload Mobility Provision · Migrate · Verify
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | const route = '/tenants/aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa/inventory/sites/bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb/operator-inputs';
  3  | test('collects operator inputs, preserves zero and uncertain saves, and remains usable on mobile', async ({ page, request }, info) => {
  4  |   await request.post('/__operators', { data: { reset: true } });
  5  |   const errors: string[] = []; page.on('pageerror', error => errors.push(error.message));
  6  |   await page.setViewportSize({ width: 1600, height: 1100 });
  7  |   await page.goto(route);
  8  |   await expect(page.getByRole('heading', { name: 'Operator readiness', exact: true })).toBeFocused();
  9  |   await page.getByLabel('Task', { exact: true }).selectOption('provision');
  10 |   await expect(page.getByLabel('Source platform execution account reference', { exact: true })).toHaveCount(0);
  11 |   await page.getByLabel('Task', { exact: true }).selectOption('migrate');
  12 |   await expect(page.getByLabel('Migration method', { exact: true })).toHaveValue('VM_COLD_EXPORT');
  13 |   await page.getByRole('button', { name: /Application recovery and cutover/ }).click();
  14 |   await expect(page.locator('#delta_ref')).toHaveCount(0);
  15 |   await page.getByLabel('Migration method', { exact: true }).selectOption('VM_SNAPSHOT_BASELINE_APP_DELTA');
  16 |   await expect(page.locator('#delta_ref')).toBeVisible();
  17 |   await page.getByLabel('Migration method', { exact: true }).selectOption('VM_COLD_EXPORT');
  18 |   await page.getByRole('button', { name: /Accounts and trust/ }).click();
  19 |   await page.getByLabel('Source platform execution account reference', { exact: true }).fill('vault:site/source-execution');
  20 |   await page.getByLabel('Source platform verification account reference', { exact: true }).fill('vault:site/source-verification');
  21 |   await page.screenshot({ path: info.outputPath('operator-readiness-desktop.png'), fullPage: true });
  22 |   await page.getByRole('button', { name: /Operating targets/ }).click();
  23 |   await page.getByLabel('Maximum application outage (seconds)', { exact: true }).fill('0');
  24 |   await page.getByLabel('Maximum data loss (bytes)', { exact: true }).fill('0');
  25 |   await request.post('/__operators', { data: { uncertain: true } });
  26 |   await page.getByRole('button', { name: 'Save operator inputs', exact: true }).click();
  27 |   await expect(page.getByRole('alert')).toBeFocused();
  28 |   await expect(page.getByRole('button', { name: 'Save operator inputs', exact: true })).toBeDisabled();
  29 |   await page.getByRole('button', { name: 'Recover unchanged save' }).click();
  30 |   await expect(page.getByRole('status')).toContainText('Operator inputs saved.');
  31 |   let state = await (await request.get('/__operators')).json();
  32 |   expect(state.posts).toHaveLength(2); expect(state.posts[0]).toEqual(state.posts[1]);
  33 |   expect(state.posts[0].input.context).toEqual({ operation: 'migrate', method: 'VM_COLD_EXPORT' });
  34 |   expect(state.posts[0].input.values.max_outage_seconds).toBe(0);
  35 |   expect(state.posts[0].input.values.max_data_loss_bytes).toBe(0);
  36 |   const download = await request.get(route + '/download');
  37 |   expect((await download.json()).native_write_authorized).toBe(false);
  38 |   await expect(page.getByRole('link', { name: 'Download saved packet' })).toBeVisible();
  39 |   await request.post('/__operators', { data: { evidence: { field_id: 'max_outage_seconds', state: 'verified', expires_at: Math.floor(Date.now()/1000) + 3 } } });
  40 |   await page.getByRole('button', { name: 'Recheck evidence' }).click();
> 41 |   await expect(page.getByText('Evidence verified', { exact: true })).toBeVisible();
     |                                                                      ^ Error: expect(locator).toBeVisible() failed
  42 |   await expect(page.getByText('Review expired', { exact: true })).toBeVisible({ timeout: 5000 });
  43 |   await page.setViewportSize({ width: 390, height: 844 });
  44 |   await page.getByRole('button', { name: 'Workspace navigation', exact: true }).click();
  45 |   await expect(page.getByRole('link', { name: 'Observed inventory', exact: true })).toBeVisible();
  46 |   await expect(page.getByRole('button', { name: 'Sign out', exact: true })).toBeVisible();
  47 |   await page.getByRole('button', { name: 'Close navigation', exact: true }).click();
  48 |   expect(await page.locator('body').evaluate(el => el.scrollWidth <= window.innerWidth)).toBe(true);
  49 |   await page.screenshot({ path: info.outputPath('operator-readiness-mobile.png'), fullPage: true });
  50 |   await page.getByRole('button', { name: /Accounts and trust/ }).click();
  51 |   await page.getByLabel('Source platform execution account reference', { exact: true }).fill('vault:site/updated');
  52 |   await expect(page.getByRole('link', { name: 'Download saved packet' })).toHaveCount(0);
  53 |   await request.post('/__operators', { data: { stale: true } });
  54 |   await page.getByRole('button', { name: 'Save operator inputs', exact: true }).click();
  55 |   await expect(page.getByRole('alert')).toContainText('A saved revision');
  56 |   await expect(page.getByLabel('Source platform execution account reference', { exact: true })).toHaveValue('vault:site/updated');
  57 |   await expect(page.getByRole('button', { name: 'Save operator inputs', exact: true })).toBeDisabled();
  58 |   await request.post('/__operators', { data: { access: 403 } });
  59 |   await expect(page).toHaveURL(/\/account$/, { timeout: 25_000 });
  60 |   expect(errors).toEqual([]);
  61 | });
  62 | 
```